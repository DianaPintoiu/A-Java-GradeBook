package Tema1;

import java.util.Vector;

public class Notification{
    //daca se produce vreo schimbare
     private Grade grade;

    public Notification(Grade grade){
        this.grade = grade;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
