package Tema1;

public interface StrategyStudent {

    public Student getbestGrade(Course course);
}
